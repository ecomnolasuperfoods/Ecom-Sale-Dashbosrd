"""รวมแดชบอร์ดทั้งหมดเป็นไฟล์ HTML ไฟล์เดียว เปิดได้โดยไม่ต้องมี server

วิธีใช้:
    python3 scripts/build_standalone.py

ผลลัพธ์: dist/nola-dashboard.html
"""
import os, json, re

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
read = lambda *p: open(os.path.join(ROOT, *p), encoding='utf-8').read()

html = read('index.html')
css = read('assets', 'styles.css')
app = read('assets', 'app.js')
chart = read('assets', 'chart.umd.js')
data = read('data', 'data.json')

# ให้ app.js อ่านข้อมูลจากตัวแปรในหน้าเว็บแทนการ fetch
app = app.replace(
    "fetch('data/data.json', { cache: 'no-cache' })\n    .then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); })",
    "Promise.resolve(window.__NOLA_DATA__)"
)

html = html.replace('<link rel="stylesheet" href="assets/styles.css">',
                    '<style>\n' + css + '\n</style>')
html = html.replace('<script src="assets/chart.umd.js"></script>',
                    '<script>\n' + chart + '\n</script>')
# หน้า TikTok เป็นไฟล์แยก ไฟล์เดียวจบจึงต้องฝังเข้ามาเป็น base64 (app.js อ่านจากตัวแปรนี้)
import base64
tt_path = os.path.join(ROOT, 'assets', 'tiktok-funnel.html')
tt_tag = ''
if os.path.exists(tt_path):
    tt_b64 = base64.b64encode(open(tt_path, 'rb').read()).decode('ascii')
    tt_tag = '<script>window.__NOLA_TT__ = "' + tt_b64 + '";</script>\n'

html = html.replace('<script src="assets/app.js"></script>',
                    '<script>window.__NOLA_DATA__ = ' + data + ';</script>\n'
                    + tt_tag + '<script>\n' + app + '\n</script>')

# เหลือ 'assets/tiktok-funnel.html' ได้ในโค้ด app.js (เป็นทางสำรองที่ไม่ถูกใช้เมื่อฝัง base64 แล้ว)
# แต่ต้องไม่เหลือ tag ที่ชี้ไปไฟล์ภายนอกจริง ๆ
for bad in ('src="assets/', "src='assets/", 'href="assets/', "href='assets/"):
    assert bad not in html, 'ยังมีลิงก์ไปยังไฟล์ภายนอกหลงเหลืออยู่: ' + bad
assert '__NOLA_TT__ = "' in html, 'ไม่ได้ฝังหน้า TikTok เข้ามา — เช็ก assets/tiktok-funnel.html'

out_dir = os.path.join(ROOT, 'dist')
os.makedirs(out_dir, exist_ok=True)
out = os.path.join(out_dir, 'nola-dashboard.html')
open(out, 'w', encoding='utf-8').write(html)
print('เขียน:', out, os.path.getsize(out), 'bytes')
